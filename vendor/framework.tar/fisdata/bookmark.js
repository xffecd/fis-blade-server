javascript: void
function() {
    var d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    document.cookie = 'FIS_DEBUG_DATA=4f10e208f47bfb4d35a5e6f115a6df1a;path=/;expires=' + d.toGMTString() + '';
    location.reload();
}();